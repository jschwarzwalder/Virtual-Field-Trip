# Cardboard Sample Project
## Spatial Audio

Copyright (c) 2015 Google Inc. All rights reserved.

This is a complete Unity 5 sample project demonstrating the use of Cardboard Spatial Audio support.

For more information see:
[https://developers.google.com/cardboard/unity/guide](https://developers.google.com/cardboard/unity/guide)
