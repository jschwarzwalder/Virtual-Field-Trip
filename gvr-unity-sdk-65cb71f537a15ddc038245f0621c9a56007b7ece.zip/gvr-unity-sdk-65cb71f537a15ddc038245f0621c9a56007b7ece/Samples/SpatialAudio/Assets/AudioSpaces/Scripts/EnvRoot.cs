﻿using UnityEngine;
using System.Collections;

public class EnvRoot : MonoBehaviour {
	public MeshRenderer Guitar;
	public MeshRenderer GuitarPedestal;
	public MeshRenderer Phone;
	public MeshRenderer PhonePedestal;
	public MeshRenderer Bird;
	public MeshRenderer BirdPedestal;
	public MeshRenderer Clock;
	public MeshRenderer ClockPedestal;
}
