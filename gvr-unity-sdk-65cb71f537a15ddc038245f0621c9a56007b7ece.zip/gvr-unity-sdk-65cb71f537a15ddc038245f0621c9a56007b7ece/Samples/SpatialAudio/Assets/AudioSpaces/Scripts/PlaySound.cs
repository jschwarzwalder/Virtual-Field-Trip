using UnityEngine;
using System.Collections;

public class PlaySound : MonoBehaviour {
	public CardboardAudioSource sound;
	[HideInInspector]
	public MeshRenderer pedestal;
	[HideInInspector]
	public MeshRenderer source;
}
