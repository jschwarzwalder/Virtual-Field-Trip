# Cardboard SDK for Unity

Copyright (c) 2014 Google Inc. All rights reserved.

For first time users, see:
[https://developers.google.com/cardboard/unity/get-started](https://developers.google.com/cardboard/unity/get-started)

For updates, known issues, upgrade instructions, see:
[https://developers.google.com/cardboard/unity/release-notes](https://developers.google.com/cardboard/unity/release-notes)
